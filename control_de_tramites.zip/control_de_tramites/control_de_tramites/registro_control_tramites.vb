﻿Partial Class registro_control_tramites
End Class

Namespace registro_control_tramitesTableAdapters
    
    Partial Public Class registro_control_tramitesTableAdapter
    End Class
End Namespace
